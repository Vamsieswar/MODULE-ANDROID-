package com.example.job_portal_clg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'package:shared_preferences/shared_preferences.dart';

class JobApplyModel {
// Create Student

  List<String> name = [];
  List<String> emailid = [];
  List<String> contact = [];
  List<String> passed = [];
  List<String> address = [];
  List<String> category = [];
  List<String> title = [];

  Future<void> createJobApply() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    name = prefs.getStringList('name') ?? [];
    emailid = prefs.getStringList('emailid') ?? [];
    contact = prefs.getStringList('contact') ?? [];
    passed = prefs.getStringList('passe') ?? [];
    address = prefs.getStringList('address') ?? [];
    category = prefs.getStringList('category') ?? [];
    title = prefs.getStringList('title') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('name', name);
    prefs.setStringList('emailid', emailid);
    prefs.setStringList('contact', contact);
    prefs.setStringList('passe', passed);
    prefs.setStringList('address', address);
    prefs.setStringList('category', category);
    prefs.setStringList('title', title);
  }

  // Remove data at a specific index
  void removeDataAtIndex(int index) {

    name.removeAt(index);
    emailid.removeAt(index);
    contact.removeAt(index);
    passed.removeAt(index);
    address.removeAt(index);
    category.removeAt(index);
    title.removeAt(index);

  }

}
import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';
import 'package:job_portal_clg/user/message_model.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  final TextEditingController emailTextEditingController =
      TextEditingController();
  final TextEditingController nameTextEditingController =
      TextEditingController();
  final TextEditingController subTextEditingController =
      TextEditingController();
  final TextEditingController messageTextEditingController =
      TextEditingController();

  MessageModel _model = MessageModel();

  Future<void> _initData() async {
    await _model.createStudentData(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model
        .saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(children: [
              Container(
                height: 300,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(
                          "assets/images/bg4.png",
                        ),
                        fit: BoxFit.cover)),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.only(top: 230.0),
                    child: Text(
                      "Contact !!!",
                      style: CommonStyles.whiteText20BoldW500(),
                      textAlign: TextAlign.end,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    ElevatedButton(
                        onPressed: () {},
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(flex: 1, child: Icon(Icons.location_on)),
                              SizedBox(
                                width: 15,
                              ),
                              Expanded(
                                flex: 9,
                                child: Text("OMR - Chennai.",
                                    style: CommonStyles.whiteText13BoldW500()),
                              ),
                            ],
                          ),
                        ),
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.green),
                            shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                    side: BorderSide(color: Colors.blue))))),
                    SizedBox(
                      height: 15,
                    ),
                    ElevatedButton(
                        onPressed: () {},
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(flex: 1, child: Icon(Icons.mail)),
                              SizedBox(
                                width: 15,
                              ),
                              Expanded(
                                flex: 9,
                                child: Text("talentinfo@gmail.com",
                                    style: CommonStyles.whiteText13BoldW500()),
                              ),
                            ],
                          ),
                        ),
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.green),
                            shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                    side: BorderSide(color: Colors.blue))))),
                    SizedBox(
                      height: 15,
                    ),
                    ElevatedButton(
                        onPressed: () {},
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 10, horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(
                                  flex: 1, child: Icon(Icons.contact_phone)),
                              SizedBox(
                                width: 15,
                              ),
                              Expanded(
                                flex: 9,
                                child: Text("003-0984-862",
                                    style: CommonStyles.whiteText13BoldW500()),
                              ),
                            ],
                          ),
                        ),
                        style: ButtonStyle(
                            backgroundColor:
                                MaterialStateProperty.all(Colors.green),
                            shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12.0),
                                    side: BorderSide(color: Colors.blue))))),
                    SizedBox(
                      height: 15,
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "Your Name",
                      style: CommonStyles.blue14900(),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextFormField(
                      controller: nameTextEditingController,
                      style: CommonStyles.black13thin(),
                      decoration: InputDecoration(
                        hintText: "Your Name",
                        labelStyle: CommonStyles.black13thin(),
                        hintStyle: CommonStyles.black13thin(),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13)),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "Your Email",
                      style: CommonStyles.blue14900(),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextFormField(
                      controller: emailTextEditingController,
                      style: CommonStyles.black13thin(),
                      decoration: InputDecoration(
                        hintText: "Your Email",
                        labelStyle: CommonStyles.black13thin(),
                        hintStyle: CommonStyles.black13thin(),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13)),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "Subject",
                      style: CommonStyles.blue14900(),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextFormField(
                      controller: subTextEditingController,
                      style: CommonStyles.black13thin(),
                      decoration: InputDecoration(
                        hintText: "Subject",
                        labelStyle: CommonStyles.black13thin(),
                        hintStyle: CommonStyles.black13thin(),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13)),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "Your Message",
                      style: CommonStyles.blue14900(),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextFormField(
                      controller: messageTextEditingController,
                      maxLines: 6,
                      style: CommonStyles.black13thin(),
                      decoration: InputDecoration(
                        hintText: "Your Message",
                        labelStyle: CommonStyles.black13thin(),
                        hintStyle: CommonStyles.black13thin(),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(13)),
                      ),
                    ),
                    SizedBox(
                      height: 50,
                    ),
                    Center(
                      child: ElevatedButton(
                          onPressed: () async {
                            if (nameTextEditingController.text.isNotEmpty &&
                                subTextEditingController.text.isNotEmpty &&
                                emailTextEditingController.text.isNotEmpty &&
                                messageTextEditingController.text.isNotEmpty) {
                              _model.mname.add(nameTextEditingController.text);
                              _model.memailid
                                  .add(subTextEditingController.text);
                              _model.msub.add(emailTextEditingController.text);
                              _model.mmessage
                                  .add(messageTextEditingController.text);

                              await _model.saveData();

                              await _model.createStudentData();

                              nameTextEditingController.clear();
                              emailTextEditingController.clear();
                              subTextEditingController.clear();
                              messageTextEditingController.clear();

                              setState(() {
                                _model.createStudentData();
                                _model.saveData();
                              });
                              showAlertDialog(context);
                            } else {
                              showAlerErrortDialog(context);
                            }
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 10, horizontal: 10),
                            child: Text("SEND MESSAGE",
                                style: CommonStyles.whiteText15BoldW500()),
                          ),
                          style: ButtonStyle(
                              backgroundColor:
                                  MaterialStateProperty.all(Colors.green),
                              shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12.0),
                                      side: BorderSide(color: Colors.blue))))),
                    ),
                  ],
                ),
              )
            ])));
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Contact Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check Entered Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Contact Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Your Message will be sent !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}

import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';
import 'package:job_portal_clg/login_screen.dart';
import 'package:job_portal_clg/user/about_screen.dart';
import 'package:job_portal_clg/user/contact_screen.dart';
import 'package:job_portal_clg/user/home_scree.dart';
import 'package:job_portal_clg/user/job_screen.dart';
import 'package:titled_navigation_bar/titled_navigation_bar.dart';



class UserDashBoard extends StatefulWidget {
  const UserDashBoard({super.key});

  @override
  State<UserDashBoard> createState() => _UserDashBoardState();
}

class _UserDashBoardState extends State<UserDashBoard> {


  int bodyIndex = 0;
  List<Widget> body = [
    const HomeScreen(),

    const AboutScreen(),
    const JobScreen(),
    const ContactScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        automaticallyImplyLeading: false,
        title: Text("HUBSPOT",
        style: CommonStyles.blackw54s20Thin(),
        ),
        actions: [
          IconButton(onPressed: (){
            setState(() {


            });
          }, icon: Icon(Icons.replay_circle_filled_rounded)),


          IconButton(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                      (route) => false, // Keep removing routes until this condition is met
                );
              },
              icon: Icon(
                Icons.login_outlined,

              )),
        ],
      ),
      backgroundColor: Colors.grey[300],
      body: IndexedStack(
        index: bodyIndex,
        children: body,
      ),
      bottomNavigationBar: buildBottomNavigationBar(),
    );
  }

  buildBody() {
    return body.elementAt(bodyIndex);
  }

  buildBottomNavigationBar() {
    return TitledBottomNavigationBar(
        activeColor: Colors.blue,
        inactiveColor: Colors.blue.shade900,
        height: 65,
        currentIndex: bodyIndex,
        onTap: (index) {
          setState(() {
            bodyIndex = index;
          });
        },
        items: [
          TitledNavigationBarItem(
            title: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.home),
                SizedBox(
                  height: 5,
                ),
                Text(
                  'Home'.toUpperCase(),
                  style: CommonStyles.black12(),
                ),
              ],
            ),
            icon: const Icon(Icons.home),
          ),

          TitledNavigationBarItem(
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.app_blocking_outlined),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'About'.toUpperCase(),
                    style: CommonStyles.black12(),
                  ),
                ],
              ),
              icon: const Icon(Icons.app_blocking_outlined)),

          TitledNavigationBarItem(
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.work_history),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'Job'.toUpperCase(),
                    style: CommonStyles.black12(),
                  ),
                ],
              ),
              icon: const Icon(Icons.work_history)),
          TitledNavigationBarItem(
              title: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.contact_phone),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'Contact'.toUpperCase(),
                    style: CommonStyles.black12(),
                  ),
                ],
              ),
              icon: const Icon(Icons.contact_phone)),

        ]);
  }
}

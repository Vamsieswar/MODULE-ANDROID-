import 'package:shared_preferences/shared_preferences.dart';

class MessageModel {
// Create Student

  List<String> mname = [];
  List<String> memailid = [];
  List<String> msub = [];
  List<String> mmessage = [];

  Future<void> createStudentData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    mname = prefs.getStringList('mname') ?? [];
    memailid = prefs.getStringList('memailid') ?? [];
    msub = prefs.getStringList('msub') ?? [];
    mmessage = prefs.getStringList('mmessage') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('mname', mname);
    prefs.setStringList('memailid', memailid);
    prefs.setStringList('msub', msub);
    prefs.setStringList('mmessage', mmessage);
  }

  // Remove data at a specific index
  void removeDataAtIndex(int index) {

    mname.removeAt(index);
    memailid.removeAt(index);
    msub.removeAt(index);
    mmessage.removeAt(index);

  }

}
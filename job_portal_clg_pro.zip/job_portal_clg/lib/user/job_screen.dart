import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';
import 'package:job_portal_clg/user/job_applied_screen.dart';
import 'package:job_portal_clg/user/job_apply_screen.dart';

class JobScreen extends StatefulWidget {
  const JobScreen({super.key});

  @override
  State<JobScreen> createState() => _JobScreenState();
}

class _JobScreenState extends State<JobScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            Container(
              height: 300,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(
                        "assets/images/bg4.png",
                      ),
                      fit: BoxFit.cover)),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 230.0),
                  child: Text(
                    "Job !!!",
                    style: CommonStyles.whiteText20BoldW500(),
                    textAlign: TextAlign.end,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 30,
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                    onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => JobApplyScreen(
                       title: "Software Engineer",
                    )));
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 20),
                      child: Text(
                          "Apply Job",
                          style:CommonStyles.whiteText13BoldW500()
                      ),
                    ),
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.green),
                        shape:
                        MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                side: BorderSide(color: Colors.blue))))),

                ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => JobAppliedScreen(
platform: "user",
                      )));
                    },
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 20),
                      child: Text(
                          "Applied Job",
                          style:CommonStyles.whiteText13BoldW500()
                      ),
                    ),
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all(Colors.green),
                        shape:
                        MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.0),
                                side: BorderSide(color: Colors.blue))))),

              ],
            ),

            SizedBox(
              height: 30,
            ),
            ListView.builder(
                itemCount: 10,
                shrinkWrap: true,
                primary: false,
                itemBuilder: (context, index) {
                  return Card(
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                              flex: 1,
                              child: Image.asset("assets/images/bg.jpg")),
                          SizedBox(
                            width: 10,
                          ),
                          
                          Expanded(
                              flex: 4,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                Text("  Software Engineer",
                                style: CommonStyles.black13(),
                                ),
SizedBox(
  height: 10,
),
                                 Row(

                                   children: [
                                     Row(
                                       children: [


                                         Icon(Icons.timelapse,
                                           size: 15,

                                         ),
                                         Text("  Full Time    ",
                                         style: CommonStyles.black11(),
                                         )
                                       ],
                                     ),

                                     Row(
                                       children: [


                                         Icon(Icons.currency_rupee,
                                           size: 15,

                                        ),
                                         Text("  5 LPA",
                                           style: CommonStyles.black11(),

                                         )
                                       ],
                                     )
                                   ],
                                 ),


                                  SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    children: [


                                       Icon(Icons.location_on,
                                         size: 15,
                                       ),
                                      Text("  Chennai",
                                        style: CommonStyles.black11(),
                                      )
                                    ],
                                  ),
                                
                                
                              ],)),
                          
                          Expanded(
                              flex: 2,
                              child:    Column(
                                children: [
                                  ElevatedButton(
                                  onPressed: () {
                                    Navigator.of(context).push(MaterialPageRoute(builder: (context)=> JobApplyScreen(
                                      title: 'Sofware Engineer',
                                    )));
                                  },
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 0),
                                    child: Text(
                                        "Apply",
                                        style:CommonStyles.white12()
                                    ),
                                  ),
                                  style: ButtonStyle(
                                      backgroundColor: MaterialStateProperty.all(Colors.green),
                                      shape:
                                      MaterialStateProperty.all<RoundedRectangleBorder>(
                                          RoundedRectangleBorder(
                                              borderRadius: BorderRadius.circular(12.0),
                                              side: BorderSide(color: Colors.blue))))),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Row(
                                    children: [


                                      Icon(Icons.date_range,
                                        size: 15,
                                      ),
                                      Text("  15-02-2023",
                                        style: CommonStyles.black11(),
                                      )
                                    ],
                                  ),
                                ],
                              ))
                        ],
                      ),
                    ),
                  );
                })
          ],
        ),
      ),
    );
  }
}

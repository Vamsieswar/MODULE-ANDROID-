import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
         Container(
           height: 300,
           width: MediaQuery.of(context).size.width,
           decoration: BoxDecoration(
             image: DecorationImage(
                 image: AssetImage(
                   "assets/images/bg3.png",
                 ),
                 fit: BoxFit.cover)
         ),
           child: Center(
             child: Text("Find The Poerfect Job That \nYou Deserved",
             style: CommonStyles.redText20BoldW500(),
             ),
           ),
         )
        ],
      ),
    );
  }
}

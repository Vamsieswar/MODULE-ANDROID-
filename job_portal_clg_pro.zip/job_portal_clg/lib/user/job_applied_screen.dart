import 'dart:typed_data';
import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart' as path_provider;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';
import 'package:job_portal_clg/user/job_apply_model.dart';

class JobAppliedScreen extends StatefulWidget {
  final String platform;

  JobAppliedScreen({super.key, required this.platform});

  @override
  State<JobAppliedScreen> createState() => _JobAppliedScreenState();
}

class _JobAppliedScreenState extends State<JobAppliedScreen> {
  JobApplyModel _model = JobApplyModel();
  bool isAprove = false;

  Future<void> _initData() async {
    await _model.createJobApply(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
    // Load data when initializing the state
  }

  Future<void> _loadFileFromPrefs() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? base64String = prefs.getString('file');
    if (base64String != null) {
      // Convert base64 string to bytes
      Uint8List fileBytes = base64Decode(base64String);

      // Write bytes to a temporary file
      Directory tempDir =
          await path_provider.getApplicationDocumentsDirectory();
      String tempFilePath = '${tempDir.path}/temp_file';
      await File(tempFilePath).writeAsBytes(fileBytes);

      setState(() {
        _filePath = tempFilePath;
      });
    } else {
      setState(() {
        _filePath = '';
      });
    }
  }

  String _filePath = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text(
          "HUBSPOT",
          style: CommonStyles.blackw54s20Thin(),
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _model.name.length != 0
                  ? ListView.builder(
                      primary: false,
                      shrinkWrap: true,
                      itemCount: _model.name.length,
                      itemBuilder: (context, index) {
                        print(" -------" + _model.name.length.toString());
                        return Card(
                          elevation: 10,
                          shadowColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 2,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Job Title",
                                            style: CommonStyles.black13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "Name",
                                            style: CommonStyles.black13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "Email",
                                            style: CommonStyles.black13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "Contact",
                                            style: CommonStyles.black13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "Passed Out",
                                            style: CommonStyles.black13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "Category",
                                            style: CommonStyles.black13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "Address",
                                            style: CommonStyles.black13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Expanded(
                                      flex: 4,
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            _model.title[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            _model.name[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            _model.emailid[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            _model.contact[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            _model.passed[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            _model.category[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            _model.address[index],
                                            style: CommonStyles.blue13900(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                if (widget.platform == 'admin')
                                  ElevatedButton(
                                    onPressed: _loadFileFromPrefs,
                                    child: Text(
                                      'Download Resume',
                                      style: CommonStyles.red12(),
                                    ),
                                  ),
                                if (widget.platform == 'admin')
                                  SizedBox(
                                    height: 15,
                                  ),
                                if (widget.platform == 'admin')
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      SizedBox(height: 20),
                                      _filePath.isNotEmpty
                                          ? Text(
                                              'Downloaded File Path: $_filePath',
                                              style: CommonStyles.black11(),
                                            )
                                          : Text(
                                              'No file Download',
                                              style: CommonStyles.black11(),
                                            ),
                                    ],
                                  ),
                                if (widget.platform == 'admin')
                                  SizedBox(
                                    height: 15,
                                  ),
                                if (widget.platform == 'admin')
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        children: [
                                          Text(
                                            "Status",
                                            style: CommonStyles.black13(),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            isAprove == true
                                                ? "Approved"
                                                : "Rejected",
                                            style: isAprove == true
                                                ? CommonStyles.green15()
                                                : CommonStyles.red15(),
                                          ),
                                        ],
                                      ),
                                      ElevatedButton(
                                          onPressed: () {
                                            setState(() {
                                              isAprove = !isAprove;
                                            });
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                                vertical: 5, horizontal: 0),
                                            child: Text(
                                                isAprove == false
                                                    ? "Approve"
                                                    : "Reject",
                                                style: CommonStyles.white12()),
                                          ),
                                          style: ButtonStyle(
                                              backgroundColor:
                                                  MaterialStateProperty.all(
                                                      Colors.green),
                                              shape: MaterialStateProperty.all<
                                                      RoundedRectangleBorder>(
                                                  RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.0),
                                                      side: BorderSide(
                                                          color:
                                                              Colors.blue))))),
                                    ],
                                  )

                                /* IconButton(onPressed: (){
                                setState(() {
                                  _model.removeDataAtIndex(index);
                                });

                              }, icon: Icon(Icons.delete,
                                size: 28,
                                color: Colors.red,
                              ))*/
                              ],
                            ),
                          ),
                        );
                      })
                  : Center(
                      child: Text(
                        "No Job Applied !!!",
                        style: CommonStyles.blackS16Thin(),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }
}

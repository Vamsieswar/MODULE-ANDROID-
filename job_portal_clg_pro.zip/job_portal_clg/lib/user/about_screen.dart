import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';


class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen> {


  final CarouselController controller = CarouselController();
  int activeIndex = 1;

  // int exploreIndex = 0;

  List<String> imageBanner = [
    'assets/images/bg.jpg',
    'assets/images/bg2.png',
    'assets/images/bg3.png',
    'assets/images/bg4.png',
  ];


  @override
  Widget build(BuildContext context) {
    return Container(
      child: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          children: [
            Container(
              height: 300,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage(
                        "assets/images/bg4.png",
                      ),
                      fit: BoxFit.cover)
              ),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 230.0),
                  child: Text("About Us !!!",
                    style: CommonStyles.whiteText20BoldW500(),
                    textAlign: TextAlign.end,
                  ),
                ),
              ),
            ),

            SizedBox(
              height: 20,
            ),

            Container(
              padding: EdgeInsets.symmetric(
                horizontal: 50
              ),
              child: Column(
                children: [
                  Text("We Help To Get The Best Job And Fina A Talent !!!",
                    style: CommonStyles.blackText17BoldW500(),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),

            SizedBox(
              height: 20,
            ),

            CarouselSlider.builder(
                carouselController: controller,
                itemCount: imageBanner.length,
                itemBuilder: (context, currentIndex, realIndex) {
                  return Container(
                    width: MediaQuery.of(context).size.width * 0.85,
                    height: 150,
                    margin: EdgeInsets.symmetric(horizontal: 0, vertical: 10),
                    child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset(
                          imageBanner[currentIndex],
                          fit: BoxFit.fill,
                        )),
                  );
                },
                options: CarouselOptions(
                  height: 200,
                  autoPlay: true,
                  pageSnapping: true,
                  autoPlayCurve: Curves.easeInOut,
                  // enableInfiniteScroll: false,
                  //  enlargeStrategy: CenterPageEnlargeStrategy.height,
                  //   viewportFraction: 1,
                  enlargeCenterPage: true,
                  //    initialPage: 0,
                  // aspectRatio: 16/9,
                  autoPlayInterval: Duration(seconds: 2),
                  onPageChanged: (index, reason) =>
                      setState(() => activeIndex = index),
                )),
            SizedBox(
              height: 20,
            ),
            
            Container(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  Text("Job portals, or job boards, are sites where you can advertise jobs and search for resumes. They are an integral part of almost every hiring process and using them effectively will translate into qualified candidates for relatively low costs.",
                  style: CommonStyles.black13(),
                  ),
                ],
              ),
            ),

            SizedBox(
              height: 0,
            ),

            Container(
              padding: EdgeInsets.all(20),
              child: Column(
                children: [
                  Row(
                    children: [
                      Icon(Icons.check,
                       color: Colors.red,
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Text("Job portals, or job boards, are sites where you can advertise jobs and search for resumes.",
                          style: CommonStyles.black13(),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Icon(Icons.check,
                        color: Colors.red,
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Text("Top companies listed.",
                          style: CommonStyles.black13(),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 10,
                  ),  Row(
                    children: [
                      Icon(Icons.check,
                        color: Colors.red,
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Text("Top recruiting companies.",
                          style: CommonStyles.black13(),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 10,
                  ),

                  Row(
                    children: [
                      Icon(Icons.check,
                        color: Colors.red,
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Text("Training material.",
                          style: CommonStyles.black13(),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    children: [
                      Icon(Icons.check,
                        color: Colors.red,
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        child: Text("Reputation.",
                          style: CommonStyles.black13(),
                        ),
                      ),
                    ],
                  ),

                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

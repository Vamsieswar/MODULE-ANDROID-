import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:job_portal_clg/admin/add_category_model.dart';
import 'package:path_provider/path_provider.dart' as path_provider;
import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';
import 'package:job_portal_clg/user/job_apply_model.dart';
import 'package:shared_preferences/shared_preferences.dart';



class JobApplyScreen extends StatefulWidget {

  final String title;
   JobApplyScreen({super.key, required this.title});

  @override
  State<JobApplyScreen> createState() => _JobApplyScreenState();
}

class _JobApplyScreenState extends State<JobApplyScreen> {

  final TextEditingController emailTextEditingController = TextEditingController();
  final TextEditingController nameTextEditingController = TextEditingController();
  final TextEditingController contactTextEditingController = TextEditingController();
  final TextEditingController passedTextEditingController = TextEditingController();
  final TextEditingController addressTextEditingController = TextEditingController();
  final TextEditingController categoryTextEditingController = TextEditingController();




  JobApplyModel _model = JobApplyModel();
  AddCategoryListModel _catModel = AddCategoryListModel();


  bool _viewCat = false;


  Future<void> _initData() async {
    await _model.createJobApply(); // Load data when initializing the state
    await _catModel.createCategory(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }
  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {

    });
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model.saveData();
    _catModel.saveData();// Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }


  String _filePath = '';

  // Function to pick a file and save it to shared preferences
  Future<void> _pickAndSaveFile() async {
    // Pick a file using file_picker
    String? filePath = await FilePicker.platform.pickFiles().then((value) {
      if (value != null) {
        return value.files.single.path;
      } else {
        return null;
      }
    });

    if (filePath != null) {
      setState(() {
        _filePath = filePath;
      });

      // Read file as bytes
      Uint8List fileBytes = await File(filePath).readAsBytes();

      // Convert bytes to base64 string
      String base64String = base64Encode(fileBytes);

      // Save base64 string to shared preferences
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('file', base64String);
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("HUBSPOT",
          style: CommonStyles.blackw54s20Thin(),
        ),
      ),
body: Container(
  child: SingleChildScrollView(
    physics: BouncingScrollPhysics(),
    child: Column(
      children: [
        Container(
          height: 300,
          width: MediaQuery.of(context).size.width,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage(
                    "assets/images/bg4.png",
                  ),
                  fit: BoxFit.cover)),
          child: Center(
            child: Padding(
              padding: const EdgeInsets.only(top: 230.0),
              child: Text(
                "Job Apply !!!",
                style: CommonStyles.whiteText20BoldW500(),
                textAlign: TextAlign.end,
              ),
            ),
          ),
        ),
        SizedBox(
          height: 30,
        ),


        Container(
          padding: EdgeInsets.symmetric(
              horizontal: 20,

          ),
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Text("Job Application Form ",
                    style: CommonStyles.blackText17BoldW500(),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),

                Text(
                  "Name",
                  style: CommonStyles.blue14900(),
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: nameTextEditingController,
                  style: CommonStyles.black13thin(),
                  decoration: InputDecoration(
                    hintText: "Your Name",
                    labelStyle: CommonStyles.black13thin(),
                    hintStyle: CommonStyles.black13thin(),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),


                ////////

                Text(
                  "Email",
                  style: CommonStyles.blue14900(),
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: emailTextEditingController,
                  style: CommonStyles.black13thin(),
                  decoration: InputDecoration(
                    hintText: "Your Email",
                    labelStyle: CommonStyles.black13thin(),
                    hintStyle: CommonStyles.black13thin(),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),

                ////////////////

                Text(
                  "Contact",
                  style: CommonStyles.blue14900(),
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  maxLength: 10,
                        keyboardType: TextInputType.number,
                  controller: contactTextEditingController,
                  style: CommonStyles.black13thin(),
                  decoration: InputDecoration(
                    counterText: '',

                    hintText: "Your Contact",
                    labelStyle: CommonStyles.black13thin(),
                    hintStyle: CommonStyles.black13thin(),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                ////////////////
                Text(
                  "Passed Out Year",
                  style: CommonStyles.blue14900(),
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                  controller: passedTextEditingController,
                  style: CommonStyles.black13thin(),
                  decoration: InputDecoration(
                    counterText: '',
                    hintText: "Your Passed Out Year",
                    labelStyle: CommonStyles.black13thin(),
                    hintStyle: CommonStyles.black13thin(),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                /////////////

                Text(
                  "Category",
                  style: CommonStyles.blue14900(),
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  readOnly: true,
                  onTap: (){
                    setState(() {

                      _viewCat = !_viewCat;
                    });
                  },
                  controller: categoryTextEditingController,
                  style: CommonStyles.black13thin(),
                  decoration: InputDecoration(
                    hintText: "Your Category",
                    labelStyle: CommonStyles.black13thin(),
                    hintStyle: CommonStyles.black13thin(),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),


              if(_viewCat == true)  ListView.builder(
                    shrinkWrap: true,
                    itemCount: _catModel.lcat.length,
                    itemBuilder: (contex,i){
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 10,
                          ),
                          TextButton(onPressed: (){
                            setState(() {
                              categoryTextEditingController.text = _catModel.lcat[i];
                              _viewCat = false;
                            });
                          }, child: Row(
                            children: [
                              Icon(Icons.category,color: Colors.black,),
                              Text("           "+_catModel.lcat[i],
                              style: CommonStyles.black12(),
                              ),
                            ],
                          )),
                        ],
                      );
                    }),

                SizedBox(
                  height: 20,
                ),

                //////////////
                Text(
                  "Address",
                  style: CommonStyles.blue14900(),
                ),
                SizedBox(
                  height: 10,
                ),
                TextFormField(
                  controller: addressTextEditingController,
                  style: CommonStyles.black13thin(),
                  decoration: InputDecoration(
                    hintText: "Your Address",
                    labelStyle: CommonStyles.black13thin(),
                    hintStyle: CommonStyles.black13thin(),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(13)),
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                /////////////
                Text(
                  "Upload Your Resume",
                  style: CommonStyles.blue14900(),
                ),
                SizedBox(
                  height: 10,
                ),
                //////////////////
                ElevatedButton(
                  onPressed: _pickAndSaveFile,
                  child: Text('Upload File',
                  style: CommonStyles.red12(),
                  ),
                ),
                SizedBox(height: 20),
                _filePath.isNotEmpty
                    ? Text('File Path: $_filePath')
                    : Text('No file selected'),

                SizedBox(height: 50,),
                Center(
                  child: ElevatedButton(
                      onPressed: () async{

                        if (nameTextEditingController.text.isNotEmpty &&
                            emailTextEditingController.text.isNotEmpty &&
                            contactTextEditingController.text.isNotEmpty &&
                            passedTextEditingController.text.isNotEmpty &&
                            addressTextEditingController.text.isNotEmpty &&
                            categoryTextEditingController.text.isNotEmpty
                        ) {

                          _model.name.add(nameTextEditingController.text);
                          _model.emailid.add(emailTextEditingController.text);
                          _model.contact.add(contactTextEditingController.text);
                          _model.passed.add(passedTextEditingController.text);
                          _model.address.add(addressTextEditingController.text);
                          _model.category.add(categoryTextEditingController.text);
                          _model.title.add(widget.title);


                          await _model.saveData();

                          await _model.createJobApply();

                          nameTextEditingController.clear();
                          emailTextEditingController.clear();
                          contactTextEditingController.clear();
                          passedTextEditingController.clear();
                          addressTextEditingController.clear();
                          categoryTextEditingController.clear();


                          setState(() {
                            _model.createJobApply();
                            _model.saveData();
                          });
                          showAlertDialog(context);

                        } else {
                          showAlerErrortDialog(context);
                        }

                      },

                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 10, horizontal: 10),
                        child: Text("Apply Job",
                            style: CommonStyles
                                .whiteText15BoldW500()),
                      ),
                      style: ButtonStyle(
                          backgroundColor:
                          MaterialStateProperty.all(
                              Colors.green),
                          shape: MaterialStateProperty.all<
                              RoundedRectangleBorder>(
                              RoundedRectangleBorder(
                                  borderRadius:
                                  BorderRadius.circular(
                                      12.0),
                                  side: BorderSide(
                                      color: Colors.blue))))),
                ),

SizedBox(
  height: 30,
)
              ],
            ),
          ),
        ),
      ],
    ),
  ),
),
    );
  }
  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Job Apply Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check Entered Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
        Navigator.of(context).pop();
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Job Apply Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Successfully Applied !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }


  /////////////

  Future<void> uploadFile(File file) async {
    String filePath = file.path;
    print("File uploaded from path: $filePath");
   // _prefs.setString('uploaded_file_path', filePath);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text("File uploaded successfully!"),
    ));
  }
}

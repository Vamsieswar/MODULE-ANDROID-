import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';
import 'package:job_portal_clg/login_screen.dart';

class LoginSelectionScreen extends StatefulWidget {
  const LoginSelectionScreen({super.key});

  @override
  State<LoginSelectionScreen> createState() => _LoginSelectionScreenState();
}

class _LoginSelectionScreenState extends State<LoginSelectionScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage(
                  "assets/images/bg.jpg",
                ),
                fit: BoxFit.cover)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InkWell(
              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=> LoginScreen()));
              },
              child: Card(
                child: SizedBox(
                  height: 50,
                  width: 250,
                  child: Center(
                    child: Text(
                      "Admin Login",
                      style: CommonStyles.blackText17BoldW500(),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            InkWell(

              onTap: (){
                Navigator.of(context).push(MaterialPageRoute(builder: (context)=> LoginScreen()));
              },
              child: Card(
                child: SizedBox(
                  height: 50,
                  width: 250,
                  child: Center(
                    child: Text(
                      "User Login",
                      style: CommonStyles.blackText17BoldW500(),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

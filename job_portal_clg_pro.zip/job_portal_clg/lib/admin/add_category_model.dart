
import 'package:shared_preferences/shared_preferences.dart';

class AddCategoryListModel {
// Create Student

  List<String> lcat = [
    "HR Management",
    "Project Management",
    "Maintaining",
    'IT support',
  ];

  Future<void> createCategory() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    lcat = prefs.getStringList('lcat') ?? [];
  }

  Future<void> saveData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList('lcat', lcat);
  }

  // Remove data at a specific index
  void removeDataAtIndex(int index) {

    lcat.removeAt(index);

  }

}
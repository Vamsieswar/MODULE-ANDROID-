import 'package:flutter/material.dart';
import 'package:job_portal_clg/admin/add_category.dart';
import 'package:job_portal_clg/admin/main_cat.dart';
import 'package:job_portal_clg/common.dart';
import 'package:job_portal_clg/login_screen.dart';
import 'package:job_portal_clg/user/job_applied_screen.dart';
import 'package:job_portal_clg/user/job_apply_model.dart';

class AdminDashBoard extends StatefulWidget {
  const AdminDashBoard({super.key});

  @override
  State<AdminDashBoard> createState() => _AdminDashBoardState();
}

class _AdminDashBoardState extends State<AdminDashBoard> {
  JobApplyModel _model = JobApplyModel();

  Future<void> _initData() async {
    await _model.createJobApply(); // Load data when initializing the state
    setState(() {}); // Trigger a rebuild to update the UI
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
    // Load data when initializing the state
  }

  @override
  void dispose() {
    _model
        .saveData(); // Save data when the screen is disposed (e.g., navigating back)
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Colors.blue,
        automaticallyImplyLeading: false,
        title: Text(
          "HUBSPOT",
          style: CommonStyles.blackw54s20Thin(),
        ),
        actions: [
          IconButton(
              onPressed: () {
                setState(() {});
              },
              icon: Icon(Icons.replay_circle_filled_rounded)),
          IconButton(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                  (route) =>
                      false, // Keep removing routes until this condition is met
                );
              },
              icon: Icon(
                Icons.login_outlined,
              )),
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Center(
              child: Card(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                  child: Text(
                    "Admin DashBoard",
                    style: CommonStyles.blackS18(),
                  ),
                ),
                elevation: 20,
                shadowColor: Colors.white,
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Center(
              child: Card(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.note_alt_sharp)),
                          Column(
                            children: [
                              Text(
                                _model.name.length.toString(),
                                style: CommonStyles.black13(),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                "Job Request",
                                style: CommonStyles.black13(),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => JobAppliedScreen(
                                      platform: "admin",
                                    )));
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 0),
                            child: Text("View Details",
                                style: CommonStyles.white12()),
                          ),
                          style: ButtonStyle(
                              backgroundColor:
                                  MaterialStateProperty.all(Colors.green),
                              shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12.0),
                                      side: BorderSide(color: Colors.blue))))),
                    ],
                  ),
                ),
                elevation: 20,
                shadowColor: Colors.white,
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Center(
              child: Card(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.note_alt_sharp)),
                          Column(
                            children: [
                              Text(
                                "+",
                                style: CommonStyles.black13(),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                "Add Category",
                                style: CommonStyles.black13(),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => AddCategoryScreen(

                                )));
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 0),
                            child: Text("View Details",
                                style: CommonStyles.white12()),
                          ),
                          style: ButtonStyle(
                              backgroundColor:
                                  MaterialStateProperty.all(Colors.green),
                              shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12.0),
                                      side: BorderSide(color: Colors.blue))))),
                    ],
                  ),
                ),
                elevation: 20,
                shadowColor: Colors.white,
              ),
            ),
            SizedBox(
              height: 30,
            ),
            Center(
              child: Card(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 40, vertical: 10),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.note_alt_sharp)),
                          Column(
                            children: [
                              Text(
                                _model.name.length.toString(),
                                style: CommonStyles.black13(),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Text(
                                "Man Category",
                                style: CommonStyles.black13(),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      ElevatedButton(
                          onPressed: () {
                            Navigator.of(context).push(MaterialPageRoute(
                                builder: (context) => MainCatScreen(

                                )));


                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                vertical: 5, horizontal: 0),
                            child: Text("View Details",
                                style: CommonStyles.white12()),
                          ),
                          style: ButtonStyle(
                              backgroundColor:
                                  MaterialStateProperty.all(Colors.green),
                              shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(12.0),
                                      side: BorderSide(color: Colors.blue))))),
                    ],
                  ),
                ),
                elevation: 20,
                shadowColor: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

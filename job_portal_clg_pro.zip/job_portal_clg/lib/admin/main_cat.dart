import 'package:flutter/material.dart';
import 'package:job_portal_clg/common.dart';




class MainCatScreen extends StatefulWidget {
  const MainCatScreen({super.key});

  @override
  State<MainCatScreen> createState() => _MainCatScreenState();
}

class _MainCatScreenState extends State<MainCatScreen> {

  List<String> cat = [
    "HR Management",
    "Project Management",
    "Maintaining",
    'IT support'
  ];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        automaticallyImplyLeading: false,
        title: Text(
          "HUBSPOT",
          style: CommonStyles.blackw54s20Thin(),
        ),

      ),


      body: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text("Manage Category",
              style: CommonStyles.blackS18(),
            ),

            SizedBox(
              height: 30,
            ),
            Row(

              children: [

                Expanded(
                  child: Text("S.No",
                  style: CommonStyles.blue13900(),
                  ),
                ),

                SizedBox(
                  width: 20,
                ),

                Expanded(
                  flex: 3,
                  child: Text("Category",
                  style: CommonStyles.blue13900(),
                  ),
                ) ,SizedBox(
                  width: 20,
                ),

                Expanded(
                  flex: 2,
                  child: Text("Action",
                  style: CommonStyles.blue13900(),
                  ),
                )
              ],
            ),

            SizedBox(
              height: 15,
            ),
            ListView.builder(
                itemCount: cat.length,
                shrinkWrap: true,
                primary: false,
                itemBuilder: (context,index){
                  return Row(

                    children: [

                      Expanded(
                        child: Text("${index+1}".toString(),
                          style: CommonStyles.black13(),
                        ),
                      ),

                      SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        flex: 3,
                        child: Text(cat[index
                        ],
                          style: CommonStyles.black13(),
                        ),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        flex: 2,
                        child: TextButton(
                          onPressed: (){
                            setState(() {
                              cat.removeAt(index);
                            });
                          },
                          child: Text("Disable",
                            style: CommonStyles.red15(),
                          ),
                        ),
                      ),

                      SizedBox(
                        width: 20,
                      ),

                    ],
                  );
                })

          ],
        ),
      ),
    );
  }
}

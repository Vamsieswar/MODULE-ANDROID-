import 'package:flutter/material.dart';
import 'package:job_portal_clg/admin/add_category_model.dart';
import 'package:job_portal_clg/common.dart';

class AddCategoryScreen extends StatefulWidget {
  const AddCategoryScreen({super.key});

  @override
  State<AddCategoryScreen> createState() => _AddCategoryScreenState();
}

class _AddCategoryScreenState extends State<AddCategoryScreen> {
  final TextEditingController catText = TextEditingController();

  AddCategoryListModel _model = AddCategoryListModel();

  Future<void> _initData() async {
    await _model.createCategory();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _initData();
    setState(() {});
  }

  @override
  void dispose() {
    _model.saveData();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        automaticallyImplyLeading: false,
        title: Text(
          "HUBSPOT",
          style: CommonStyles.blackw54s20Thin(),
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              "Add Category",
              style: CommonStyles.blackS18(),
            ),
            SizedBox(
              height: 20,
            ),
            TextFormField(
              controller: catText,
              style: CommonStyles.black13thin(),
              decoration: InputDecoration(
                hintText: "Add Category",
                labelStyle: CommonStyles.black13thin(),
                hintStyle: CommonStyles.black13thin(),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(13)),
              ),
            ),
            SizedBox(
              height: 100,
            ),
            Center(
              child: ElevatedButton(
                  onPressed: () async {
                    if (catText.text.isNotEmpty) {
                      _model.lcat.add(catText.text);

                      await _model.saveData();

                      await _model.createCategory();

                      catText.clear();

                      setState(() {
                        _model.createCategory();
                        _model.saveData();
                      });
                      showAlertDialog(context);
                    } else {
                      showAlerErrortDialog(context);
                    }
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 10, horizontal: 10),
                    child: Text("Add Category",
                        style: CommonStyles.whiteText15BoldW500()),
                  ),
                  style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all(Colors.green),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12.0),
                              side: BorderSide(color: Colors.blue))))),
            ),
          ],
        ),
      ),
    );
  }

  showAlerErrortDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Add Category Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Check Entered Details !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  showAlertDialog(BuildContext context) {
    // set up the button
    Widget okButton = TextButton(
      child: Text(
        "OK",
        style: CommonStyles.green15(),
      ),
      onPressed: () {
        Navigator.pop(context);
        Navigator.of(context).pop();
      },
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text(
        "Add Category Info Message !!!",
        style: CommonStyles.black15(),
      ),
      content: Text(
        "Successfully Added !!!...",
        style: CommonStyles.black13(),
      ),
      actions: [
        okButton,
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
}
